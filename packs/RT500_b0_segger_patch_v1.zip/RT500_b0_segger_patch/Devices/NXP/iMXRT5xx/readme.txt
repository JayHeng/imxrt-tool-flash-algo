Replace the flash alogrithm files under <Jlink_install_dir>\Devices\NXP\iMXRT5xx\ folder such as C:\Program Files (x86)\SEGGER\JLink\Devices\NXP\iMXRT5xx using the provided files:
    MIMXRT5XX_FLEXSPI.FLM
    MIMXRT5XX_FLEXSPI_S.FLM.