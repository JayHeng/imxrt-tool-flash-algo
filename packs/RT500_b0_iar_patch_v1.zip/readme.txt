  About this patch
   =========================================
   arm folder enables i.MX8 series Cortex-M4/M7 cores debugging in IAR v8.40.2. 

   How to use this patch
   =========================================
    Please copy the arm folder and override all the existing files in the arm folder in your IAR installer path. 
    For example, C:\Program Files (x86)\IAR Systems\Embedded Workbench 8.4\arm.